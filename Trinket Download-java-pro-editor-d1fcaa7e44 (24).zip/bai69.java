import java.lang.*;
 public class bai69 {
 public static void main(String[] args)
 {
    String main_string = "Python";    
    System.out.println(main_string.substring(0, main_string.length()/2));	
  } 
 }
