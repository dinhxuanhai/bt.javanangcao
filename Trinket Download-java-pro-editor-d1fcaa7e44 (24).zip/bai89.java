import java.lang.*;
 public class bai89 {
 public static void main(String[] args)
 {
	System.out.println("System security interface:");
    System.out.println(System.getSecurityManager());	 
  }
}