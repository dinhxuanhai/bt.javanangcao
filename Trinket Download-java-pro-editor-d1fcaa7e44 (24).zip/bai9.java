public class bai9 {
 
    public static void main(String[] arg) {

        System.out.println((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
    }
}
