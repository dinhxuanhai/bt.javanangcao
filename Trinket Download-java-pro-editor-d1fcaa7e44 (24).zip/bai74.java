import java.lang.*;
 public class bai74 {
 public static void main(String[] args)
 {
    int[] num_array = {10, -20, 0, 30, 40, 60, 10};
    System.out.println((num_array[0] == 10 || num_array[num_array.length-1] == 10));	
 }
}