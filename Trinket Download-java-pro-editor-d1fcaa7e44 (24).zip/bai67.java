import java.lang.*;
 public class bai67 {
 public static void main(String[] args)
 {
   String main_string = "Python 3.0";
   String word = "Tutorial";
   System.out.println(main_string.substring(0, 7) + word + main_string.substring(6));
	}
}