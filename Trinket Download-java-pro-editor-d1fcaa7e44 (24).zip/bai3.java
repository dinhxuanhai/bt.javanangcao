package JavaNangCao;

public class bai3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(50/3);
		
	}

}
