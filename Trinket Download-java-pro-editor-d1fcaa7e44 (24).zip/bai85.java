import java.util.*; 
import java.io.*; 
 public class bai85 {
 public static void main(String[] args)
 {
   String string1 = "Hello how are you?";
    System.out.println(string1.startsWith("Hello"));
  }
}