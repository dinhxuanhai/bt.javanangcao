
public class bai41 {

	public static void main(String[] String) {
		int chr = 'Z';
		System.out.println("The ASCII value of Z is :"+chr);
	}