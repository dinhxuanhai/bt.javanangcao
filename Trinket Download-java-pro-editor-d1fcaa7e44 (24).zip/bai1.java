public class bai1 {
  public static void main(String[] args) {
  // Write your code here
  System.out.println("hello");
		System.out.println("Đinh Xuân Hải");
 }
}