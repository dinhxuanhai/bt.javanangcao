package JavaNangCao;

public class bai2 {
	double sum;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(74 + 36 );
	}

}
